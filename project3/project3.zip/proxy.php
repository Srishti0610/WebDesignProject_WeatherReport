<?php
  // put your API key here:
  $appid = "1fe3d9b81d3809fede178e8bfed78250";

  header("Content-type: application/json\n\n");
  $params = $_SERVER['QUERY_STRING'];
  $host = "https://api.openweathermap.org/data/2.5/weather?$params&APPID=$appid";
  $ch = curl_init($host);
  curl_exec($ch);
  curl_close($ch);
?>
